import psycopg2

def create():
    conn = psycopg2.connect(dbname="postgres",user="postgres", password ="111111", host="localhost", port="5432")
    cur = conn.cursor()
    cur.execute('''create table student(ID serial, Name text, Age text, Department text)''')
    print("Table Created")
    conn.commit()
    conn.close()

def insert():
    conn = psycopg2.connect(dbname="postgres",user="postgres", password ="111111", host="localhost", port="5432")
    cur = conn.cursor()
    Name = input("Enter your name: ")
    Age = input("Enter your age: ")
    Department = input("Enter your department: ")

    query = '''insert into student(Name,Age,Department) values(%s,%s,%s);'''
    cur.execute(query,(Name,Age,Department))
    
    print("Table Created")
    conn.commit()
    conn.close()

insert()